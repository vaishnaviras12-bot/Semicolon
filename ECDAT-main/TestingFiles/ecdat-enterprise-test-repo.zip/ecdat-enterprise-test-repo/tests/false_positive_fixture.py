# Crypto-looking strings for false-positive testing only.
algorithm_name = "RSA"
url = "https://example.invalid/api/sha256"
comment = "AES-256-GCM is mentioned here only as documentation"
