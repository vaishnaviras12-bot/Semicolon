# ECDAT Enterprise Test Repository

Synthetic enterprise-scale cryptographic discovery target for local ECDAT scanner testing.

Coverage includes source code, algorithms, hashes, keys, certificates, protocols,
libraries/dependencies, Docker, Kubernetes, Helm, Terraform/IaC, cloud KMS,
HSM/PKCS#11 signals, storage encryption, CI/CD, and false-positive controls.

Everything is synthetic. No production credentials, private keys, or real secrets
are included. The repository is deterministic so scanner runs can be compared.

See ground-truth/ for the expected inventory.
