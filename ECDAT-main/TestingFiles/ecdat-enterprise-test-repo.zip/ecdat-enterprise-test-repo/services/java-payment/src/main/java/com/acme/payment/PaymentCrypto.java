package com.acme.payment;

import javax.crypto.Cipher;
import java.security.Signature;

public class PaymentCrypto {
    public byte[] encrypt(byte[] plaintext) throws Exception {
        // AES-256-GCM
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        return cipher.doFinal(plaintext);
    }

    public byte[] sign(byte[] payload, java.security.PrivateKey key) throws Exception {
        // ECDSA using NIST P-256 / secp256r1
        Signature signature = Signature.getInstance("SHA256withECDSA");
        signature.initSign(key);
        signature.update(payload);
        return signature.sign();
    }
}
