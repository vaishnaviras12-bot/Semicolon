import hashlib

def legacy_checksum(data: bytes):
    # Intentionally legacy algorithms for discovery testing.
    md5_value = hashlib.md5(data).hexdigest()
    sha1_value = hashlib.sha1(data).hexdigest()
    return md5_value, sha1_value

# False-positive control: name only, not a crypto implementation.
cryptographic_policy_documentation = "architecture-not-an-implementation"
