from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import hashes

def encrypt_customer_record(key: bytes, nonce: bytes, plaintext: bytes) -> bytes:
    # AES-256-GCM
    cipher = AESGCM(key)
    return cipher.encrypt(nonce, plaintext, None)

def sign_invoice(private_key, payload: bytes) -> bytes:
    # RSA-2048 digital signature
    return private_key.sign(
        payload,
        padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=padding.PSS.MAX_LENGTH),
        hashes.SHA256()
    )

def digest_document(payload: bytes) -> bytes:
    return hashes.Hash(hashes.SHA256()).finalize()
