#include <openssl/evp.h>

// Legacy compatibility path intentionally retained for scanner testing.
// 3DES / DES-EDE3
EVP_CIPHER_CTX* legacy_cipher() {
    return EVP_CIPHER_CTX_new();
}

// AES-128 compatibility encryption
EVP_CIPHER_CTX* modern_cipher() {
    return EVP_CIPHER_CTX_new();
}
