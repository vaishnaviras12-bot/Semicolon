import { createSecureContext } from "node:tls";
import { createCipheriv } from "node:crypto";

// TLS 1.3 gateway configuration
export const tlsOptions = {
  minVersion: "TLSv1.3",
  ciphers: "TLS_AES_256_GCM_SHA384:TLS_CHACHA20_POLY1305_SHA256"
};

// ChaCha20-Poly1305 application encryption example
export function protect(payload: Buffer, key: Buffer, nonce: Buffer) {
  return createCipheriv("chacha20-poly1305", key, nonce, { authTagLength: 16 });
}
