module example.internal/go-worker

go 1.23

require golang.org/x/crypto v0.28.0
