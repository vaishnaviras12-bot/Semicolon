package worker

import (
    "crypto/ecdh"
    "crypto/hmac"
    "crypto/sha256"
    "golang.org/x/crypto/hkdf"
)

func deriveSessionKey(privateKey *ecdh.PrivateKey, peer *ecdh.PublicKey) []byte {
    // ECDH P-256 key agreement
    shared, _ := privateKey.ECDH(peer)

    // HKDF-SHA256 key derivation
    reader := hkdf.New(sha256.New, shared, nil, []byte("enterprise-session"))
    out := make([]byte, 32)
    reader.Read(out)

    // HMAC-SHA256 message authentication
    mac := hmac.New(sha256.New, out)
    mac.Write([]byte("message"))
    return mac.Sum(nil)
}
