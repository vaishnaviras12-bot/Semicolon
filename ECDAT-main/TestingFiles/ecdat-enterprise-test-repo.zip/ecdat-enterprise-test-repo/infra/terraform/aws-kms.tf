resource "aws_kms_key" "payments" {
  description         = "Synthetic payment encryption key"
  enable_key_rotation = true
}
resource "aws_kms_alias" "payments" {
  name          = "alias/enterprise-payments"
  target_key_id = aws_kms_key.payments.key_id
}
