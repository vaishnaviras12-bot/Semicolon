resource "google_kms_key_ring" "enterprise" {
  name = "synthetic-enterprise"
  location = "global"
}
resource "google_kms_crypto_key" "application" {
  name = "application-key"
  key_ring = google_kms_key_ring.enterprise.id
}
