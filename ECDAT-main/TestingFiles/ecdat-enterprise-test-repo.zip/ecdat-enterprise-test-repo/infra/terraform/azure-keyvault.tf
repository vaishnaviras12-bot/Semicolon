resource "azurerm_key_vault" "enterprise" {
  name                = "synthetic-enterprise-kv"
  location            = "test-region"
  resource_group_name = "synthetic-rg"
  tenant_id           = "00000000-0000-0000-0000-000000000000"
  sku_name            = "standard"
}
