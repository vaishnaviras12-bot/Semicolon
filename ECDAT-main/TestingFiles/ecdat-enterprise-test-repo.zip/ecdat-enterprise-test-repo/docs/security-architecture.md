# Synthetic Security Architecture

The production architecture would use encryption in transit and at rest.
This document is descriptive and intentionally contains crypto terminology that
should not by itself become an implementation finding.

Terms mentioned for documentation testing:
RSA, AES, SHA-256, TLS, certificates, HSM, KMS.

No cryptographic operation is implemented in this document.
