#include <openssl/evp.h>
#include <openssl/rsa.h>
#include <openssl/ec.h>
#include <openssl/hmac.h>
#include <openssl/sha.h>

void ecdat_test() {
    // RSA signing/verification family
    EVP_DigestSignInit(nullptr, nullptr, EVP_sha256(), nullptr, nullptr);

    // ECDSA
    EC_KEY *ec = EC_KEY_new_by_curve_name(NID_X9_62_prime256v1);

    // SHA-1 legacy hash
    unsigned char digest[SHA_DIGEST_LENGTH];
    SHA1((const unsigned char*)"legacy", 6, digest);

    // HMAC-SHA256
    HMAC(EVP_sha256(), "key", 3, (const unsigned char*)"data", 4, digest, nullptr);
}
