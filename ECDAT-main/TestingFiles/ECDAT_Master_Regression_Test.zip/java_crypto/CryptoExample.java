import java.security.*;
import java.security.spec.ECGenParameterSpec;
import javax.crypto.Cipher;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

public class CryptoExample {
    public void run() throws Exception {
        // RSA signing
        Signature rsaSign = Signature.getInstance("SHA256withRSA");
        rsaSign.initSign(KeyPairGenerator.getInstance("RSA").generateKeyPair().getPrivate());

        // ECDSA signing
        Signature ecdsa = Signature.getInstance("SHA256withECDSA");

        // ECDH key establishment
        KeyAgreementExample();

        // AES-GCM
        Cipher aes = Cipher.getInstance("AES/GCM/NoPadding");

        // HMAC-SHA256
        Mac hmac = Mac.getInstance("HmacSHA256");

        // SHA-1 legacy
        MessageDigest legacy = MessageDigest.getInstance("SHA-1");
    }

    private void KeyAgreementExample() {
        // Evidence string intentionally explicit for scanner correlation.
        String algorithm = "ECDH";
        System.out.println(algorithm);
    }
}
