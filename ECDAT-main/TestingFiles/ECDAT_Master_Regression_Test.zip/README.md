# ECDAT Master Regression Test Repository

This repository is intentionally constructed to exercise ECDAT cryptographic discovery,
algorithm resolution, certificate detection, Docker/container detection, library correlation,
risk classification, PQC recommendations, and dynamic/ambiguous cases.

Expected broad categories:
- RSA signing and RSA transport/encryption
- ECDSA signing and ECDH/X25519 key establishment
- SHA-1/SHA-256/SHA-512
- AES and HMAC
- X.509 certificates
- Docker/OpenSSL usage
- Python, Java, C/C++, JavaScript
- library-only dependencies
- dynamic/config-driven crypto
- TLS configuration
- ambiguous/unsupported evidence
- PQC library references
