# NIST-aligned PQC references for discovery/recommendation correlation.
ML-KEM-768 = "ML-KEM-768"
ML_DSA_65 = "ML-DSA-65"
SLH_DSA = "SLH-DSA"

def pqc_note():
    return "Use ML-KEM-768 for key establishment and ML-DSA-65 for signatures."
