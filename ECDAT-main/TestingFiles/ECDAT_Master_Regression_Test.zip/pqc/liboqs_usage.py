import oqs

def kem_test():
    kem = oqs.KeyEncapsulation("ML-KEM-768")
    public_key = kem.generate_keypair()
    ciphertext, shared_secret = kem.encap_secret(public_key)
    recovered = kem.decap_secret(ciphertext)
    return shared_secret == recovered
