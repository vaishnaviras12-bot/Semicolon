const crypto = require("crypto");

// RSA signing
const signer = crypto.createSign("RSA-SHA256");

// ECDSA signing
const ecSigner = crypto.createSign("SHA256");

// AES-256-GCM
const cipher = crypto.createCipheriv(
  "aes-256-gcm",
  crypto.randomBytes(32),
  crypto.randomBytes(12)
);

// HMAC-SHA256
const hmac = crypto.createHmac("sha256", "test-key");

// SHA-1 legacy
const legacy = crypto.createHash("sha1");

// X25519-style named group evidence for configuration/usage correlation
const tlsGroup = "X25519";
