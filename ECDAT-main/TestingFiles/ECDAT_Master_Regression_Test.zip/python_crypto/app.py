from cryptography.hazmat.primitives import hashes, hmac, serialization
from cryptography.hazmat.primitives.asymmetric import rsa, ec, x25519, padding
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

# RSA signing: should resolve to RSA / signing
rsa_private = rsa.generate_private_key(public_exponent=65537, key_size=2048)
rsa_signature = rsa_private.sign(
    b"ecdAT signing test",
    padding.PKCS1v15(),
    hashes.SHA256()
)

# RSA encryption: should resolve to RSA / encryption or key-establishment semantics
rsa_public = rsa_private.public_key()
rsa_ciphertext = rsa_public.encrypt(
    b"transport test",
    padding.OAEP(
        mgf=padding.MGF1(algorithm=hashes.SHA256()),
        algorithm=hashes.SHA256(),
        label=None
    )
)

# ECDSA signing
ec_private = ec.generate_private_key(ec.SECP256R1())
ec_signature = ec_private.sign(b"ecdsa test", ec.ECDSA(hashes.SHA256()))

# ECDH key establishment
peer = ec.generate_private_key(ec.SECP256R1())
ecdh_secret = ec_private.exchange(ec.ECDH(), peer.public_key())

# X25519 key establishment
x1 = x25519.X25519PrivateKey.generate()
x2 = x25519.X25519PrivateKey.generate()
x25519_secret = x1.exchange(x2.public_key())

# AES-256-GCM symmetric encryption
aes_key = AESGCM.generate_key(bit_length=256)
aes = AESGCM(aes_key)
ciphertext = aes.encrypt(b"0123456789ab", b"ECDAT symmetric test", None)

# HMAC-SHA256
mac = hmac.HMAC(b"secret-key", hashes.SHA256())
mac.update(b"ECDAT HMAC test")
tag = mac.finalize()

# SHA-1 intentionally present for risk detection
sha1 = hashes.Hash(hashes.SHA1())
sha1.update(b"legacy hash test")
legacy_digest = sha1.finalize()

# SHA-512
sha512 = hashes.Hash(hashes.SHA512())
sha512.update(b"strong hash test")
strong_digest = sha512.finalize()
