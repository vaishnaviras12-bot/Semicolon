from cryptography.hazmat.primitives.asymmetric import rsa

# Intentionally ambiguous RSA presence without a cryptographic operation.
# Expected: unknown/needs-review rather than automatic KEM classification.
key = rsa.generate_private_key(public_exponent=65537, key_size=3072)
