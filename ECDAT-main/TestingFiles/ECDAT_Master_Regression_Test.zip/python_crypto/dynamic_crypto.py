from cryptography.hazmat.primitives import hashes

# Algorithm comes from configuration rather than being statically selected.
# Resolver should preserve dynamic/uncertain semantics rather than inventing an algorithm.
ALGORITHM = settings.CRYPTO_HASH_ALGORITHM

def make_digest(data):
    algorithm = ALGORITHM
    return algorithm(data)
