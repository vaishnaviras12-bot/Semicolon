# Crypto Policy

Current legacy systems may use:
- RSA-2048
- ECDSA P-256
- ECDH P-256
- X25519
- SHA-1 for legacy compatibility
- AES-256-GCM
- HMAC-SHA256

Migration targets:
- ML-DSA-65 for digital signatures
- ML-KEM-768 for key establishment
- Hybrid mechanisms where interoperability requires them
